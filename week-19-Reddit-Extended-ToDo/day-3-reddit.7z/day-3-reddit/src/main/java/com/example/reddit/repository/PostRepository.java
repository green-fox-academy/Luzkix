package com.example.reddit.repository;

import com.example.reddit.model.Post;
import com.example.reddit.model.User;
import com.example.reddit.model.Vote;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface PostRepository extends JpaRepository <Post, Long> {
  @Query("SELECT c FROM Post c WHERE c.owner = ?1")
  List<Post> getMyPosts(User loggedUser); //nakonec nepoužívám, využívám List<Post> přímo na Userovi

}

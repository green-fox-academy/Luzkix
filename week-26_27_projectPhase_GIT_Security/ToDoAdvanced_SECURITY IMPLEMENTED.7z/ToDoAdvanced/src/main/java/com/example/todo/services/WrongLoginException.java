package com.example.todo.services;

public class WrongLoginException extends Throwable{
  public WrongLoginException() {
    super();
  }
}

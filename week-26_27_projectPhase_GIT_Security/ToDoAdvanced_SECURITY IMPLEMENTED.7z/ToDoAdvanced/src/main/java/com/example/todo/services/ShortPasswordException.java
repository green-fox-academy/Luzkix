package com.example.todo.services;

public class ShortPasswordException extends Throwable {
  public ShortPasswordException(String s) {
  }
}

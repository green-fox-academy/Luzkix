package com.example.foxclub;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FoxclubApplicationTests {

  @Test
  void contextLoads() {
  }

}

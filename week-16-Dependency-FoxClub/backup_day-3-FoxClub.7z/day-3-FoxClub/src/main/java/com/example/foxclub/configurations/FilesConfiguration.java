package com.example.foxclub.configurations;

import org.springframework.stereotype.Component;

@Component
public class FilesConfiguration {
  public String filename = "src/main/resources/static/files/savedData/foxes.txt";
}

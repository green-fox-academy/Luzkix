package com.example.foxclub.controllers;

import com.example.foxclub.services.FoxService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class MainController {
  private static String loggedUser = new String();
  private static String checkedName = new String();
  private FoxService foxService;

  @Autowired
  public MainController(FoxService foxService) {
    this.foxService = foxService;
  }

/*  @GetMapping("/index")
  public String indexPage(@RequestParam(defaultValue = "none") String loggedUser, Model model) {
    if (loggedUser.equals("none")) {
      return "index_notLogged";
    } else {
      model.addAttribute("foxName",
          "<strong style='color: red'>" + loggedUser.toUpperCase() + "</strong>");
      return "index";
    }
  }

  @GetMapping("/")
  public String basePage(@RequestParam(defaultValue = "none") String loggedUser, Model model) {
    if (loggedUser.equals("none")) {
      return "login";
    } else {
      //model.addAttribute("foxName", "<strong style='color: red'>"+name.toUpperCase() +"</strong>");
      return "redirect:/index?name=" + loggedUser;
    }
  }

  @GetMapping("/login")
  public String loginPage() {
    return "login";
  }*/

  public static void setCheckedName(String nameToCheck) {
    checkedName = nameToCheck;
  }

  @GetMapping("/")
  public String basePage(Model model) {
    if (loggedUser.isEmpty()) {
      return "index_notLogged";
    } else {
      model.addAttribute("foxName",
          "<strong style='color: red'>" + loggedUser.toUpperCase() + "</strong>");
      return "redirect:/index";
    }
  }

  @GetMapping("/index")
  public String indexPage(Model model) {
    if (loggedUser.isEmpty()) {
      return "index_notLogged";
    } else {
      model.addAttribute("foxName",
          "<strong style='color: red'>" + loggedUser.toUpperCase() + "</strong>");
      return "index";
    }
  }

  @GetMapping("/login")
  public String loginPage() {
    return "login";
  }

  @PostMapping("/login")
  public String loginPage(@RequestParam String name, Model model) {
    if (foxService.checkFox(name)) {
      loggedUser = checkedName;
      return "redirect:index";
    } else {
      model.addAttribute("wrongUser", "The name you have provided - <strong>" + name
          + "</strong> - has not been used before, add it as a new one!");
      return "login";
    }
  }

  @GetMapping("/signup")
  public String signUpPage() {
    return "signup";
  }

  @PostMapping("/signup")
  public String signUpPage(@RequestParam String name, Model model) {
    if (foxService.checkFox(name)) {
      model.addAttribute("existingUser", "The name you have provided - <strong>" + name
          + "</strong> - is already taken as a name: " + checkedName + ". Please try a new one.");
      return "signup";
    } else {
      foxService.addFox(name);
      loggedUser=name;
      return "redirect:/";
    }
  }

  @GetMapping("/logout")
  public String logOut() {
    loggedUser="";
    System.out.println(loggedUser);
    return "redirect:/";
  }
}

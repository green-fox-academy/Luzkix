package com.example.foxclub.models;

public class Trick {
  private String trickname;

  public Trick (String trickname) {
    this.trickname=trickname;
  }

}

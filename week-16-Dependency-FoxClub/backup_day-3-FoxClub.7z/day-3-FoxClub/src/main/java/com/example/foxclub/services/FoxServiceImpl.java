package com.example.foxclub.services;

import com.example.foxclub.controllers.MainController;
import com.example.foxclub.models.Fox;
import com.example.foxclub.models.Foxes;
import com.example.foxclub.repository.FoxRepository;
import java.text.Normalizer;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class FoxServiceImpl implements FoxService {
  private final FoxRepository foxRepository;
  private final Foxes foxes;

  @Autowired
  public FoxServiceImpl(FoxRepository foxRepository, Foxes foxes) {
    this.foxRepository = foxRepository;
    this.foxes = foxes;
  }

  @Override
  public boolean checkFox(String foxName) {

/*    System.out.println(Foxes.loadAllSavedFoxes());
    for(Fox fox : Foxes.loadAllSavedFoxes()) {
      if (removeDiacritic(fox.getName().toLowerCase()).equals(removeDiacritic(foxName.toLowerCase()))) {
        MainController.setCheckedName(fox.getName());
        return true;
      }
    }
    return false;*/
  }

  @Override
  public void addFox(String foxName) {
    foxRepository.add(new Fox(foxName));
  }

  @Override
  public Fox findFoxByName(String name) {
    return null;
  }

  @Override
  public List<String[]> returnAllfoxProperties() {
    return foxRepository.returnAllfoxProperties();
  }

  //method eliminating the diactritics from names
  public static String removeDiacritic(String string) {
    return Normalizer.normalize(string, Normalizer.Form.NFD)
        .replaceAll("\\p{InCombiningDiacriticalMarks}+", "");
  }
}
